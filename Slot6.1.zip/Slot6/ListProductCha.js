import React from "react";
import { FlatList } from "react-native";
import ProductCon from "./ProductCon";
export default class ListProductCha extends React.Component{
    //code
    constructor(){
        super();
        this.state={
            prd: null,
        };
        this.hamRender=this.hamRender.bind(this);
        this.handlePressDetail=this.handlePressDetail.bind(this);
        this.getProducts=this.getProducts.bind(this);
    }
    hamRender({item}){//render item
        return(
            <ProductCon prodData={item} handlePress={this.handlePressDetail} />
        );
       
    }
    handlePressDetail(d){//click thi hien thi detail
        this.props.navigation.navigate('Detail',{data:d});
    }
    //doc du lieu tu API
    async getProducts(){
        const url='https://hungnttg.github.io/shopgiay.json';//duong dan
        const response = await fetch(url,{method:'GET'});//doc du lieu
        const responseJSON = await response.json();//chuyen sang json
        //dua du lieu vao state
        this.setState({
            prd: responseJSON.products,
        });
    }
    componentDidMount(){//ham goi khi mount component
        this.getProducts();
    }
    //layout
    render(){
        return(
            <FlatList
                data={this.state.prd}
                renderItem={this.hamRender}
                numColumns={3}
                removeClippedSubviews
            />
        );
    }

}