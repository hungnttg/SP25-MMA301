import React from "react";
import { StyleSheet,Text,View,Image,TouchableWithoutFeedback } from "react-native";
export default class ProductCon extends React.Component{
    //code
    constructor(){
        super();
        this.props={
            prodData: {},//nhan doi tuong
            handlePress: null,//nhan action
        };
        this.fun_handlePress=this.fun_handlePress.bind(this);
    }
    fun_handlePress(){//ham xu ly su kien
        this.props.handlePress?this.props.handlePress(this.props.prodData):null;
    }
    //layout
    render(){
        return(
            <TouchableWithoutFeedback onPress={this.fun_handlePress}>
                <View>
                    <Image source={{uri:this.props.prodData.search_image}} style={styles.image}/>
                    <Text>{this.props.prodData.styleid}</Text>
                    <Text>{this.props.prodData.brands_filter_facet}</Text>
                    <Text>{this.props.prodData.price}</Text>
                    <Text>{this.props.prodData.product_additional_info}</Text>
                </View>     
            </TouchableWithoutFeedback>
        );
    }
}
const styles=StyleSheet.create({
    container:{
        flex:1,
    },
    image:{
        width:200,height:200,borderWidth:1,
    },
});