const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const app=express();
app.use(cors());
const conn = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'a11'
});
conn.connect(err=>err);
app.get('/data',(req,res)=>{
    conn.query('select * from mytable',(err,results)=>{
        if(err) throw err;
        res.json({products: results});
    });
});
app.listen(3000,()=>{
    console.log("ung dung dang chay o cong 3000");
});