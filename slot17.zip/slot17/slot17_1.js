//npm i @react-navigation/native
//npm i @react-navigation/react
//npm i react-native-maps
//npm i @react-native-async-storage/async-storage
import React,{useState,useCallback} from "react";
import { Text,View,Button,TextInput,TouchableOpacity,FlatList } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { createStackNavigator } from "@react-navigation/stack";
import { NavigationContainer } from "@react-navigation/native";
import { useFocusEffect } from "@react-navigation/native";
import MapView, { Marker } from "react-native-maps";
import { useNavigation } from "@react-navigation/native";
const HomeScreen=()=>{
    const navigation = useNavigation();
    //code
    const [search,setSearch]=useState('');
    const [lands,setLands] = useState([]);
    //load du lieu
    useFocusEffect(
        useCallback(()=>{
            //dinh nghia
            const fetchLands = async () =>{
                const data = await AsyncStorage.getItem('lands');
                setLands(data ? JSON.parse(data) : []);
            };
            //goi ham
            fetchLands();
        },[])
        
    );
    const filteredLands = lands.filter(land=>land.name.includes(search) || land.location.includes(search));
    //layout
    return(
        <View>
            <TextInput placeholder="Tim kiem" onChangeText={setSearch}/>
            <FlatList
                data={filteredLands}
                keyExtractor={item=>item.id}
                renderItem={({item})=> (
                    <TouchableOpacity onPress={()=>navigation.navigate('Detail',{land:item})}>
                        <Text>{item.name} - {item.location}</Text>
                    </TouchableOpacity>
                )}
            />
            <Button title="Them manh dat" onPress={()=>navigation.navigate('Edit')}/>
        </View>
    );

};
//---
//Edit
const EditScreen = ({navigation,route})=>{
    //code
    const [name,setName]= useState(route.params?.land?.name ||'');
    const [location,setLocation]=useState(route.params?.land?.location ||'');
    const [price,setPrice] = useState(route.params?.land?.price || '');
    const [coordinate,setCoordinate]=useState(route.params?.land?.coordinate || {
        latitude: 21.0278,
        longitude: 105.8342
    });
    const handleMapPress = (e) =>{
        const {latitude,longitude} = e.nativeEvent.coordinate;
        setCoordinate({latitude,longitude});
        setLocation(`${latitude},${longitude}`);
    };
    const saveLand = async () =>{
        const newLand = {
            id: Date.now().toString(), name,location,price,coordinate
        };
        const storedLands = JSON.parse(await AsyncStorage.getItem('lands')) || [];
        const updatedLands = route.params?.land ? 
        storedLands.map(land=>(land.id===route.params.land.id ? newLand : land)) : [...storedLands,newLand];
        await AsyncStorage.setItem('lands',JSON.stringify(updatedLands));
        navigation.goBack();
    };
    //layout
    return(
        <View style={{flex:1}}>
            <TextInput placeholder="Ten" value={name} onChangeText={setName} />
            <TextInput placeholder="Vi tri" value={location} onChangeText={setLocation} />
            <TextInput placeholder="Gia" value={price} onChangeText={setPrice} />
            {/* ban do */}
            <MapView style={{flex:1}}
                initialRegion={{
                    latitude: coordinate.latitude,
                    longitude: coordinate.longitude,
                    latitudeDelta: 0.01,
                    longitudeDelta: 0.01
                }}
                onPress={handleMapPress}
            >
                <Marker coordinate={coordinate} title="Vi tri da chon"/>
            </MapView>
            <Button title="Luu" onPress={saveLand}/>
        </View>
    );
};
//--- Detail
const DetailScreen = ({route,navigation}) =>{
    const {land} = route.params;
    const deleteLand = async () =>{
        const storedLands = JSON.parse(await AsyncStorage.getItem('lands')) ||[];
        const updatedLands = 
        storedLands.filter(l=>l.id !== land.id);
        await AsyncStorage.setItem('lands',JSON.stringify(updatedLands));
        navigation.goBack();
    };
    
    return(
        <View style={{flex:1}}>
            <Text>{land.name}</Text>
            <Text>{land.location}</Text>
            <Text>{land.price}</Text>
            <MapView style={{flex:1}}
                initialRegion={{
                    ...land.coordinate, latitudeDelta:0.01, longitudeDelta:0.01
                }}
            >
                <Marker coordinate={land.coordinate} title={land.name}/>
            </MapView>
            <Button title="Xoa" onPress={deleteLand}/>
            <Button title="Chinh sua" onPress={()=>navigation.navigate('Edit',{land})} />
        </View>
    );
}
const Stack = createStackNavigator();
export default function Slot17_1(){ 
    return(
        <NavigationContainer>
            <Stack.Navigator initialRouteName="Home">
                <Stack.Screen name="Home" component={HomeScreen}/>
                <Stack.Screen name="Edit" component={EditScreen}/>
                <Stack.Screen name="Detail" component={DetailScreen}/>
            </Stack.Navigator>
        </NavigationContainer>
    );
}
