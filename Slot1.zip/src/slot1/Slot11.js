//1. import thu vien
import React from "react";
import { Text,View } from "react-native";
//2. Dinh nghia class
class Slot11 extends React.Component{
    //code
    //giao dien
    render(){
        return(
            // tra ve 1 view
            <View>
                <Text>Day la ung dung react native, viet theo class</Text>
            </View>
        );
    }

}
//3. export component
export default Slot11;