//1. import thu vien
import React from "react";
import { Text,View } from "react-native";
//2. dinh nghia ham
const Slot12 = () => {
    //code
    //giao dien
    return(
        <View>
            <Text>Day la phien ban function</Text>
        </View>
    );
}
//3. export ham
export default Slot12;
