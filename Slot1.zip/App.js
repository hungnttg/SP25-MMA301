import React from "react";
import Slot11 from "./src/slot1/Slot11";
import Slot12 from "./src/slot1/Slot12";
function App(){
    // App se goi cac component khac o day
    return(
        // <Slot11/>
        <Slot12/>
    );
    
}
export default App;