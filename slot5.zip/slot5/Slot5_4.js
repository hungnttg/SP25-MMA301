import { useState } from "react";
import { Button, View,Text } from "react-native";

//su dung ham mui ten trong useState
const Slot5_4 = () =>{
    const [count,setCount]=useState(0);
   const increment = ()=>{
        setCount(count+1);
   };
    return(
        <View style={{padding:40}}>
            <Button title="Press" onPress={()=>increment()} />
            <Text>{count}</Text>
        </View>
    );
}
export default Slot5_4;