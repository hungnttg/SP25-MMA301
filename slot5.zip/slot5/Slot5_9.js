//truyen MANG bang cau truc phan ra destructuring
import React,{useState} from "react";
import { Text,View,Button } from "react-native";
export const Slot5_9 = () =>{
    const inPhanTuMang = ([first,second]) =>{
        console.log(`First: ${first}, Second: ${second}`);
    };
    const mang=[10,20,30,40,50,60,70,80];
    return(
        <View>
            <Button title="Destructuring Array" onPress={()=>inPhanTuMang(mang)}/>
        </View>
    );
};