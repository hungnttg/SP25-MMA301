//truyen doi tuong bang cau truc phan ra destructuring
import React,{useState} from "react";
import { Text,View,Button } from "react-native";
export const Slot5_8 = () =>{
    const inThuocTinh = ({name,age})=>{
        console.log(`Name: ${name}; va Age: ${age}`);
    };
    const person1 = {name:"NVA",age:20};
    return(
        <View>
            <Button title="Destructuring Object" onPress={()=>inThuocTinh(person1)}/>
        </View>
    );
};