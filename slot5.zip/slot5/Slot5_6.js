import { useState } from "react";
import { Button, View,Text } from "react-native";

//Truyen Doi tuong vao ham mui ten
const Slot5_6 = () =>{
    const [ten,setTen]=useState('');
    const inDoiTuong=(person)=>{
        setTen(person.name);
        console.log(`Ho ten: ${person.name}; Tuoi: ${person.age}`);
    };
    const person={name: "Nguyen Van An",age: 25};
    return(
        <View style={{padding:40}}>
            <Button title="In doi tuong" onPress={()=>inDoiTuong(person)}/>
            <Text>{ten}</Text>
        </View>
    );
}
export default Slot5_6;