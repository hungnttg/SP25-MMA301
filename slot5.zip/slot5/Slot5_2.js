//- Truyền hàm không có tham số vào sự kiện
import React from "react";
import { View,Button } from "react-native";
const Slot5_2 = ()=>{
    const handlePress = () =>{
        console.log("Ban vua click vao button");
    };
    return(
        <View>
            <Button title="Click me" onPress={handlePress}/>
        </View>
    );
}
export default Slot5_2;

