import React from "react";
import { Text,View,Button } from "react-native";
const Slot5_3 = () =>{
    //truyen ham co tham so vao su kien
    const handlePress=(id)=>{
        console.log(`Truyen tham so ${id} vao ham`);
    };
    return(
        <View>
            <Button title="Press me" onPress={()=>handlePress(1)}/>
        </View>
    );
}
export default Slot5_3;