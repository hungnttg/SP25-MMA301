import React,{useState} from "react";
import { Text,View,Button } from "react-native";
export const Slot5_7 = () =>{
    const [tong,setTong]=useState(0);
    const truyenMang=(numbers)=>{
        let tong=numbers.reduce((total,num)=>total+num,0);
        setTong(tong);
        console.log("Tong la: "+tong);
        return tong;
    };
    const mang=[1,2,3,4,5];
    return(
        <View>
            <Button onPress={()=>truyenMang(mang)} title="Truyen mang"/>
            <Text>{tong}</Text>
        </View>
    );
};