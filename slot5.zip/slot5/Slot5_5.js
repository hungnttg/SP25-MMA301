import { useState } from "react";
import { Button, View,Text } from "react-native";

//Truyen bien vao ham mui ten
const Slot5_5 = () =>{
    const [ten,setTen]=useState('');
    const inTen=(name)=>{
        setTen(name);
        console.log(`Ho ten: ${name}`);
    };
  
    return(
        <View style={{padding:40}}>
            <Button title="In ten" onPress={()=>inTen("An")}/>
            <Text>{ten}</Text>
        </View>
    );
}
export default Slot5_5;