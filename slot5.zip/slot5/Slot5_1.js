//debug xu ly su kien
import React from "react";
import { Text,View,Button } from "react-native";
export default class Slot5_1 extends React.Component{
    //code
    constructor(){
        super();
        this.state=({
            counter:0,
        });
    }
    increment(){
        this.setState({
            counter: this.state.counter+1,
        });
    }
    //layout
    render(){
        return(
            <View style={{padding:50}}>
                <Text>Test debug</Text>
                <Button title="Press me" onPress={()=>this.increment()}/>
                <Text>Ban click {this.state.counter} lan</Text>
            </View>
        );
    }
}