package com.hnq40.myapplication1.slot2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.hnq40.myapplication1.R

class Slot2_4MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_slot22_main)
        var tv2 = findViewById<TextView>(R.id.slot2_2Tv2)
        val i=intent
        val chuoiA = i.extras!!.getString("chuoiA")
        val chuoiB = i.extras!!.getString("chuoiB")
        val so1 = chuoiA!!.toFloat()
        val so2 = chuoiB!!.toFloat()
        val tong = so1+so2
        tv2.text=tong.toString()
    }
}