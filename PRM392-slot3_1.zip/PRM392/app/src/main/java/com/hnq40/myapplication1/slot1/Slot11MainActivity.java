package com.hnq40.myapplication1.slot1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.hnq40.myapplication1.R;

public class Slot11MainActivity extends AppCompatActivity {
    //khai bao cac id
    TextView tv1;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot11_main);
        //anh xa cac id vao code java
        tv1 = findViewById(R.id.slot1Tv1);
        btn1=findViewById(R.id.slot1Btn1);
        //xu ly su kien
        btn1.setOnClickListener(v->{
            tv1.setText("ban vua click");
        });
    }
}