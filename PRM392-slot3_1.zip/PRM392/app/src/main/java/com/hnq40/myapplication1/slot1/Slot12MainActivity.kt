package com.hnq40.myapplication1.slot1

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.hnq40.myapplication1.R

class Slot12MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_slot12_main)
        var tv1 = findViewById<TextView>(R.id.slot12Tv2)
        var btn1  = findViewById<Button>(R.id.slot12Btn2)
        btn1.setOnClickListener({
           tv1.text="phien ban Kotlin"
        });
    }
}