package com.hnq40.myapplication1.slot2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.hnq40.myapplication1.R

class Slot2_3MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_slot21_main)
        var txt1 = findViewById<EditText>(R.id.slot2_1Txt1)
        var txt2 = findViewById<EditText>(R.id.slot2_1Txt2)
        var btn1 = findViewById<Button>(R.id.slot2_1Btn1)
        btn1.setOnClickListener({
            var i = Intent(this,Slot2_4MainActivity::class.java)
            i.putExtra("chuoiA",txt1.text.toString())
            i.putExtra("chuoiB",txt2.text.toString())
            startActivity(i)
        })
    }
}