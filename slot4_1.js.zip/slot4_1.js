import React,{useState} from "react";
import { Text,View,StyleSheet,TouchableOpacity } from "react-native";
//khai bao bien toan cuc
global.myVariable="";
export default function Slot4_1(){
    //khai bao cac bien, cac thuoc tinh
    //co 2 thuoc tinh can cap nhat moi khi click: phepTinh, ketQua
    //dung de truyen du lieu qua lai giua cac ham
    const [phepTinh,setPhepTinh]=useState('pheptinh');
    const [ketQua,setKetQua]=useState('ketqua');
    //khai bao cac bien (cuc bo)
    let resultText="";
    let calculationText="";
    //dinh nghia ham pressButton
    const pressButton = (text) =>{
        if(text=="="){//khi nhan dau =
            calculationText = global.myVariable;//nhan gia tri tu bien toan cuc
            //goi den ham tinh toan gia tri bieu thuc
            //global.myVariable="";//xoa bien toan cuc vi nhan vao dau =
            let resultText1= eval(calculationText);//tinh toan gia tri va tra ve bien resultText 
            resultText=resultText1;
            setKetQua(resultText);//cap nhat ket qua vao thuoc tinh ketQua
            return resultText1;
        }
        else if(text=="DEL"){
            calculationText=global.myVariable;
            let text = calculationText.split('');//pha vo chuoi
                
                text.pop();//xoa thanh phan cuoi cung trong chuoi
                calculationText = text.join('');
                global.myVariable = calculationText;
                //calculationText = text.join('');//join cac thanh phan con lai trong chuoi
                setPhepTinh(calculationText);
        }
        else //khi nhan vao cac button kha
        {
            //thuc hien thao tac noi chuoi
            calculationText = global.myVariable;//nhan gia tri tu bien toan cuc
            calculationText = calculationText+text;//noi chuoi
            global.myVariable = calculationText;//cap nhat vao bien toan cuc
            //sau khi setPhepTinh thi calculationText bi xoa,nhung da luu vao bien toan cuc
            setPhepTinh(calculationText);
        }
    };
    
    
    //khai bao mang de thiet ke giao dien
    //---thiet ke phan con so----
    let rows=[];//mang dong
    let nums = [[1,2,3],[4,5,6],[7,8,9],['.','0','=']];//du lieu de dien vao mang dong
    for(let i=0;i<4;i++){
        let row=[];//moi dong
        for(let j=0;j<3;j++){
            //dua button vao dong
            row.push(
                <TouchableOpacity style={styles.btn} key={nums[i][j]}
                onPress={()=>pressButton(nums[i][j])}>
                    <Text>{nums[i][j]}</Text>
                </TouchableOpacity>
            );
        }
        //dua row vao rows
        rows.push(
            <View key={i} style={styles.row}>{row}</View>
        );
    }
    //------thiet ke phan phep tinh: co 1 cot, 5 hang
    let opers = [];
    let operator = ['+','-','*','/','DEL'];
    for(let i=0;i<5;i++){
        opers.push(
            <TouchableOpacity style={styles.btn} key={operator[i]} 
            onPress={()=>pressButton(operator[i])}>
                <Text>{operator[i]}</Text>
            </TouchableOpacity>
        );
    }
    //cuoi cung chi can dua 2 mang rows va opers la xong
    return(
        <View style={styles.container}>
            {/* ket qua */}
            <View style={styles.result}>
                <Text style={styles.text1}>{ketQua}</Text>
            </View>
            {/* phep tinh */}
            <View style={styles.calculation}>
                <Text style={styles.text1}>{phepTinh}</Text>
            </View>
            {/* buttons */}
            <View style={styles.buttons}>
                <View style={styles.numbersButton}>
                    {rows}
                </View>
                <View style={styles.opersButton}>
                    {opers}
                </View>
            </View>
        </View>
    );

}
const styles = StyleSheet.create({
    container:{
        flex:1,
        flexDirection:'column',
    },
    result:{
        flex:1,
        alignItems:'flex-end',
        justifyContent:'space-around',
        backgroundColor:'yellow',
    },
    calculation:{
        flex:2,
        alignItems:'flex-end',
        justifyContent:'space-around',
        backgroundColor:'green',
    },
    buttons:{
        flex:7,
        flexDirection:'row',
        alignItems:'stretch',
        justifyContent:'space-around',
        backgroundColor:'#1a1a1a',
    },
    numbersButton:{
        flex:3,
        flexDirection:'row',
        alignItems:'stretch',
        justifyContent:'space-around',
        backgroundColor:'yellow',
    },
    opersButton:{
        flex:1,
        flexDirection:'column',
        alignItems:'stretch',
        justifyContent:'space-around',
        backgroundColor:'#a1a1a1',
    },
    btn:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
        fontSize:'30',
        fontWeight:'bold',
    },
    text1: {
        fontSize:'30',
        fontWeight:'bold',
    },

});