/*
Tạo dự án:
npx create-expo-app . --template blank
Cài thư viện:
npm install
@react-navigation/stack
@react-navigation/native
@react-navigation/bottom-tabs
react-native-screens
react-native-safe-area-context
@expo/vector-icons
*/
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";
import { Text,View } from "react-native";
const Tab = createBottomTabNavigator();
//define HomeScreen
function HomeScreen(){
    return (
        <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            <Text>Home</Text>
            {/* Them cac thanh phan khac */}
        </View>
    );
}
//define Setting Screen
function SettingsScreen(){
    return(
        <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            <Text>Settings</Text>
        </View>
    );
}
//define App.js
export default function App14(){
    return(
        <NavigationContainer>
            <Tab.Navigator>
                <Tab.Screen name="Home" component={HomeScreen}
                    options={{tabBarIcon: ({color,size})=>(
                        <Ionicons name="home" size={size} color={color}/>
                            ),
                        }}
                />
                <Tab.Screen name="Settings" component={SettingsScreen}
                
                    options={{tabBarIcon: ({color,size})=>(
                        <Ionicons name="settings" size={size} color={color} />
                    ),
                
                    }}
                />
            </Tab.Navigator>
        </NavigationContainer>
    );
}
