//npm i @react-native-async-storage/async-storage
import React,{useState,useEffect,useCallback} from "react";
import { Text,View,TextInput,Button,FlatList, TouchableOpacity } from "react-native";
import { NavigationContainer, useFocusEffect } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import AsyncStorage from "@react-native-async-storage/async-storage";

const HomeScreen = ({navigation})=>{
    const [lands,setLands] =useState([]);
    const [search,setSearch] = useState('');
    useFocusEffect(
        useCallback(()=>{
            (async () =>{
                const data = await AsyncStorage.getItem('lands');
                setLands(data ? JSON.parse(data) : []);
            })();
        },[])
    );
    return(
        <View style={{flex:1,padding:10}}>
            <TextInput placeholder="Tim kiem" onChangeText={setSearch}/>
            <FlatList
                data={lands.filter(l=>l.name.includes(search) || l.location.includes(search))}
                keyExtractor={item => item.id}
                renderItem={({item})=>(
                            <TouchableOpacity onPress={()=>{
                                navigation.navigate('Detail',{land: item})
                            }}>
                                <Text>{item.name} - {item.location}</Text>
                            </TouchableOpacity>
                    )}
            />
            <Button title="Them" onPress={()=> navigation.navigate('Edit')}/>
        </View>
    );
};
const LandScreen = ({navigation,route})=>{
    const [land,setLand] = useState(route.params?.land || 
        {id: Date.now().toString(),name: '',location:'',price: ''});
    const saveLand = async () =>{
        const storedLands = JSON.parse(await AsyncStorage.getItem('lands')) || [];
        await AsyncStorage.setItem('lands',JSON.stringify(route.params?.land ?
            storedLands.map(l=>l.id === land.id ? land : l) : [...storedLands,land]));
        navigation.goBack();
    };
    return(
        <View style={{flex:1,padding:10}}>
            <TextInput placeholder="Ten" value={land.name} onChangeText={v=> setLand({ ...land,name: v})}/>
            <TextInput placeholder="Vi tri" value={land.location} onChangeText={v=>setLand({...land,location: v})}/>
            <TextInput placeholder="Gia" value={land.price} onChangeText={v=>setLand({...land,price: v})}
                keyboardType="numeric"
                />
            <Button title="Luu" onPress={saveLand}/>
        </View>
    );
};
const DetailScreen = ({route,navigation}) =>{
    const {land} = route.params;
    const deleteLand = async () =>{
        const storedLands = JSON.parse(await AsyncStorage.getItem('lands')) || [];
        await AsyncStorage.setItem('lands',JSON.stringify(
            storedLands.filter(l=>l.id !== land.id)
        ));
        navigation.goBack();
    };
    return(
        <View style={{flex:1,padding:10}}>
            <Text>{land.name}</Text>
            <Text>{land.location}</Text>
            <Text>{land.price}</Text>
            <Button title="Sua" onPress={()=>navigation.navigate('Edit',{land})}/>
            <Button title="Xoa" onPress={deleteLand}/>
        </View>
    );
};
const Stack = createStackNavigator();
export default function Slot11_1(){
    return(
        <NavigationContainer>
            <Stack.Navigator>
                <Stack.Screen name="Home" component={HomeScreen}/>
                <Stack.Screen name="Edit" component={LandScreen}/>
                <Stack.Screen name="Detail" component={DetailScreen}/>
            </Stack.Navigator>
        </NavigationContainer>
    );
}
