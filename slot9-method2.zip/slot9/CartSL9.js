import React from "react";
import { ScrollView,Button,Text,FlatList } from "react-native";
import ProductSL9 from "./ProductSL9";
global.mycart=[];
export default class CartSL9 extends React.Component{
    //code
    constructor(props){
        super(props);
        this.state={
            list: global.mycart,
            prd: props.route?.params?.data,//receive from prev screen
            count: 1,
        };
        this.data = props.route?.params?.data;
        this.increment=this.increment.bind(this);
        this.decrement=this.decrement.bind(this);
        this.listAllProduct=this.listAllProduct.bind(this);
        this.fn_renderItem=this.fn_renderItem.bind(this);
    }
    increment(){
        this.setState({
            count: this.state.count+1,
        });
    }
    decrement(){
        this.setState({
            count: this.state.count-1,
        });
    }
    listAllProduct(){
        //method 1-------
        global.mycart.push({data:this.state.prd});
        this.setState({
            list:  [...global.mycart],//update list from newList
        });
        //method 2----------
        // const newList = [{data:this.data},...global.mycart];//push the data object to my cart
        // this.setState({
        //     list:  newList,//update list from newList
        // });
        // global.mycart=newList;
    }
    fn_renderItem({index,item}){
        //-----method 1----------------
        // return(
        //     <ProductSL9 dataProd={global.mycart[index].data}/>
        // );
        //------method 2
        return(
            <ProductSL9 dataProd={item.data}/>
        );
    }
    //layout
    render(){
        return(
            <ScrollView>
                <ProductSL9 dataProd={this.state.prd}/>
                <Button title="+" onPress={this.increment}/>
                <Button title="-" onPress={this.decrement}/>
                <Text>Sum of quantity: {this.state.count}</Text>
                <Button title="Show all product of Cart" onPress={this.listAllProduct}/>
                <FlatList
                    data={this.state.list}
                    renderItem={this.fn_renderItem}
                    numColumns={2}
                    removeClippedSubviews
                />
            </ScrollView>
        );
    }
}