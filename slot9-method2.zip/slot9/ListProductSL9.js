import React from "react";
import { FlatList } from "react-native";
import ProductSL9 from "./ProductSL9";
export default class ListProductSL9 extends React.Component{
    //code
    constructor(){
        super();
        this.state={
            prd: {}
        };
        this.fn_renderItem=this.fn_renderItem.bind(this);//register function
        this.fun_viewDetail=this.fun_viewDetail.bind(this);
        this.getProducts=this.getProducts.bind(this);
    }
    fn_renderItem({item}){//define function: render data for item
        return(
            <ProductSL9 dataProd={item} 
            handlePress={()=>this.fun_viewDetail(item)}/>
        );
    }
    fun_viewDetail(d){//define: view detail function when user press on item
        this.props.navigation.navigate('DetailSL9',{data: d})
    }
    async getProducts(){//get all products from API
        const url='https://hungnttg.github.io/shopgiay.json';
        const res = await fetch(url,{method:'GET'});//read data
        const resJSON = await res.json();//convert to json object
        this.setState({ //update state
            prd: resJSON.products,
        });
    }
    componentDidMount(){//automatic
        this.getProducts();
    }
    //layout
    render(){
        return(
            <FlatList
                data={this.state.prd}
                renderItem={this.fn_renderItem}
                numColumns={3}
                removeClippedSubviews
            />
        );
    }
}