import React from "react";
import { ScrollView,Button } from "react-native";
import ProductSL9 from "./ProductSL9";
export default class DetailSL9 extends React.Component{
    //code
    constructor(props){
        super(props);
        this.state={
            prd: props.route?.params?.data,//receive data from prev screen
        };
        this.addToCart=this.addToCart.bind(this);
    }
    addToCart(){//define function: add product to cart
        this.props.navigation.navigate('CartSL9',{data:this.state.prd});
    }
    //layout
    render(){
        return(
            <ScrollView>
                <ProductSL9 dataProd={this.state.prd}/>
                <Button title="Add to cart" onPress={this.addToCart}/>
            </ScrollView>
        );
    }
}