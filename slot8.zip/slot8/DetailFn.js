import React from "react";
import { ScrollView,Button } from "react-native";
import { useRoute } from "@react-navigation/native";//nhan du lieu chuyen sang tu ListProduct
import ProductFn from "./ProductFn";
const DetailFn = ({navigation}) =>{
    const route = useRoute();
    const d = route.params?.data || "";//nhan du lieu tu su kien viewDetail
    const addToCart = ({d1}) =>{
        navigation.navigate("CartFn",{data:d1});
    };
    return(
        <ScrollView>
            <ProductFn dataProd={d}/>
            <Button title="Add to Cart" onPress={()=>addToCart({d1:d})}/>
        </ScrollView>
    );
};
export default DetailFn;