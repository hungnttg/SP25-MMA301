import ListProductFn from "./ListProductFn";
import DetailFn from "./DetailFn";
import CartFn from "./CartFn";
import { NavigationContainer } from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
const Stack = createStackNavigator();
//khai bao cac man hinh
const NavFn = () =>{
    return(
        <NavigationContainer>
            <Stack.Navigator initialRouteName="ListProductFn">
                <Stack.Screen name="ListProductFn" component={ListProductFn}/>
                <Stack.Screen name="DetailFn" component={DetailFn}/>
                <Stack.Screen name="CartFn" component={CartFn}/>
            </Stack.Navigator>
        </NavigationContainer>
    );
}
export default NavFn;