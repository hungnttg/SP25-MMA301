import React,{useState} from "react";
import { FlatList,ScrollView,Text,View,Button } from "react-native";
import ProductFn from "./ProductFn";
global.mycart = [];
const CartFn = ({route}) =>{
    //code
    const [count,setCount]=useState(1);
    const [list,setList]=useState([]);
    const data = route.params?.data || "";
    //ham lay ve list san pham co trong gio hang
    const DanhSachSPTrongCart = () =>{
        setList(global.mycart);//lay du lieu hien thoi cua gio hang vao bien list
        const newList = [{data},...global.mycart];//dua data vao mycart
        setList(newList);//cap nhat du lieu moi cua gio hang
        global.mycart = newList; //cap nhat lai bien toan cuc

    };
    //ham ket xuat du lieu
    const renderItemCart = ({index,item})=>{
        return(
            <ProductFn dataProd={global.mycart[index].data} />
        );
    };
    //layout
    return(
        <View>
            <ScrollView>
                <ProductFn dataProd={data}/>
                <Button title="+" onPress={()=>setCount(count+1)}/>
                <Button title="-" onPress={()=>setCount(count-1)}/>
                <Text>So luong: {count}</Text>
                <Button title="Danh sach SP" onPress={DanhSachSPTrongCart}/>
                <FlatList
                    data={global.mycart} renderItem={renderItemCart}
                    numColumns={2}
                    removeClippedSubviews/>
            </ScrollView>
        </View>
    );
}
export default CartFn;