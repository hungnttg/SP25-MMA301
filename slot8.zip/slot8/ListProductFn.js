import React,{useState,useEffect} from "react";
import { FlatList } from "react-native";
import ProductFn from "./ProductFn";
import { useNavigation } from "@react-navigation/native";
//npm i @react-navigation/native
//npm i @react-navigation/stack
const ListProductFn = () =>{
    //code--------
    const [prd,setPrd]=useState(null);
    //ham ket xuat du lieu
    const renderItemFlatlist = ({item}) =>{
        return(
            <ProductFn dataProd={item} handlePress={viewDetail}/>
        );
    };  
    //ham viewDetail: chuyen man hinh -> dung navigation
    const navigation=useNavigation();
    const viewDetail = (d) =>{
        navigation.navigate('DetailFn',{data:d});
    };
    //ham doc du lieu tu API
    const getProducts = async () =>{
        const url='https://hungnttg.github.io/shopgiay.json';//duong dan
        const response = await fetch(url,{method:'GET'});//doc du lieu
        const responseJSON = await response.json();//chuyen sang json
        //update vao state
        setPrd(responseJSON.products);
    };
    useEffect(()=>{
        getProducts();//goi ham 
    },[]);
    //layout
    return(
        <FlatList
            data={prd}
            renderItem={renderItemFlatlist}
            numColumns={3}
            removeClippedSubviews
        />
    );
}
export default ListProductFn;