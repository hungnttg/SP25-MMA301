import React,{useState} from "react";
import { Text,View,TouchableOpacity,StyleSheet } from "react-native";
//global.bienToanCuc = "";
const Slot4_1 = () =>{
    //khai bao cac thuoc tinh
    const [ketQua,setKetQua]=useState('');
    const [phepTinh,setPhepTinh]=useState('');
    const [bienToanCuc,setBienToanCuc]=useState('');
    //------code
    //cac bien (tam)
    let resultText="";
    let calculationText="";
    const pressButton = (text) =>{
        if(text==="="){
            //khi click vao dau = , ta can tinh toan ket qua
            calculationText=bienToanCuc; //calculationText nhan gia tri cua bien toan cuc
            resultText = eval(calculationText);//tinh toan ket qua, tra ve resultText
            setKetQua(resultText);//thuoc tinh ketQua nhan gia tri la resultText => hien thi cho nguoi dung
        }
        else if(text==="DEL"){
            calculationText=bienToanCuc;//calculationText nhan gia tri cua bien toan cuc
            let text = calculationText.split('');//va vo chuoi
            text.pop();//xoa ky tu cuoi cung
            calculationText = text.join('');
            setBienToanCuc(calculationText);//hop cac ky tu con lai thanh 1 chuoi, tra ve bien toan cuc
            setPhepTinh(calculationText);//hien thi ket qua cho nguoi dung
        }
        else {
            //khi click vao cac button khac => noi chuoi
            calculationText = bienToanCuc; //calculationText nhan gia tri cua bien toan cuc
            calculationText = calculationText + text;//noi chuoi
            setBienToanCuc(calculationText);//cap nhat lai bien toan cuc
            setPhepTinh(calculationText);//hien thi ket qua cho nguoi dung

        }
    };
    //layout
    //----thiet ke phan number
    let rows=[];
    let nums = [[1,2,3],[4,5,6],[7,8,9],['.','0','=']];
    for(let i=0;i<4;i++){
        let row=[];//mang dong
        for(let j=0;j<3;j++){
            //dua cac con so vao row
            row.push(
                <TouchableOpacity key={nums[i][j]} style={styles.btn} onPress={()=>pressButton(nums[i][j])}>
                    <Text style={styles.textStyle}>{nums[i][j]}</Text>
                </TouchableOpacity>
            );
        };
        //dua row vao rows
        rows.push(
            <View key={i} style={styles.number1}>{row}</View>
        );
    }
    //thiet ke phan phep tinh
    let ops=[];
    let operators = ['+','-','*','/','DEL'];
    for(let i=0;i<5;i++){ 
            ops.push(
            <TouchableOpacity key={operators[i]} style={styles.btn} 
            onPress={()=>pressButton(operators[i])}>
                <Text style={styles.textStyle}>{operators[i]}</Text>
            </TouchableOpacity>
        );

        
    }
    return(
        <View style={styles.container}>
            {/* result */}
            <View style={styles.result}>
                <Text style={styles.textStyle}>{ketQua}</Text>
            </View>
            {/* phepTinh */}
            <View style={styles.calculation}>
                <Text style={styles.textStyle}>{phepTinh}</Text>
            </View>
            {/* button */}
            <View style={styles.buttons}>
                {/* number */}
                <View style={styles.numbers}>{rows}</View>
                {/* operator */}
                <View style={styles.operators}>{ops}</View>
            </View>
        </View>
    );
};
const styles = StyleSheet.create({
    container:{
        flex:1,
        flexDirection:'column',
    },
    //chia container thanh 3 phan: 1,2,7
    result:{
        flex:1,
        backgroundColor:'yellow',
        justifyContent:'space-around',
        alignItems:'flex-end',
    },
    calculation:{
        flex:2,
        backgroundColor:'green',
        justifyContent: 'space-around',
        alignItems:'flex-end',
    },
    buttons:{
        flex:7,
        flexDirection:'row',
        alignItems:'stretch',
        justifyContent:'space-around',
    },
    //chia button thanh 2 phan: 3,1
    numbers:{
        flex:3,
        flexDirection:'row',
        backgroundColor:'#a2a2a2',
        alignItems:'stretch',
        justifyContent:'space-around',
    },
    //chia number thanh 3 phan: 1,1,1
    number1:{
        flex:1,
        flexDirection:'column',
        backgroundColor:'#a3a3a3',
        alignItems:'stretch',
        justifyContent:'space-around',
    },
    number2:{
        flex:1,
        flexDirection:'column',
        backgroundColor:'#a3a3a3',
        alignItems:'stretch',
        justifyContent:'space-around',
    },
    number3:{
        flex:1,
        flexDirection:'column',
        backgroundColor:'#a3a3a3',
        alignItems:'stretch',
        justifyContent:'space-around',
    },
    operators:{
        flex:1,
        flexDirection:'column',
        backgroundColor:'#a1a1a1',
        alignItems:'stretch',
        justifyContent:'space-around',
    },
    btn:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
        fontSize:30,
        fontWeight:'bold',
    },
    row:{
        flex:1,
        flexDirection:'row',
        justifyContent:'space-around',
        alignItems:'stretch',
        fontSize:30,
        fontWeight:'bold',
    },
    textStyle:{
        fontSize:30,
        fontWeight:'bold',
    },
});
export default Slot4_1;