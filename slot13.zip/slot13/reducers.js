import { createReducer } from "@reduxjs/toolkit";
import { addItem,removeItem } from "./actions";

const initialState = {items: []};
const cartReducer = createReducer(initialState, builder => {
    builder
    .addCase(addItem, (state,action)=>{
        //lay ve id cua san pham da co trong gio hang
        const existItemIndex = state.items.findIndex(item => item.id === action.payload.id);
        if(existItemIndex !== -1){ //neu san pham da ton tai
            state.items[existItemIndex].quantity++;//so luong tang them 1
        }
        else {//neu san pham chua ton tai
            //them san pham vao gio hang, set so luong la 1
            state.items.push({...action.payload,quantity:1});
        }
    })
    .addCase(removeItem,(state,action)=>{
        //lay ve id cua san pham da co trong gio hang
        const existItemIndex = state.items.findIndex(item => item.id === action.payload.id);
        if(existItemIndex !== -1){ //neu san pham da ton tai
            state.items[existItemIndex].quantity--;//so luong giam 1
            //kiem tra neu so luong bang 0
            if(state.items[existItemIndex].quantity===0){
                state.items.splice(existItemIndex,1);//xoa san pham
            }
        }
    });
});
export default cartReducer;