import React from "react";
import { Text,View,Button } from "react-native";
import { useSelector,useDispatch } from "react-redux";
import { addItem,removeItem } from "./actions";
const Cart = () =>{
    const cartItems = useSelector(state=> state.cart.items);
    const dispatch = useDispatch();
    return(
        <View>
            {cartItems.map(item =>(
                <View key={item.id}>
                    <Text>{item.name} - {item.quantity}</Text>
                    <Button title="Remove item from cart"
                        onPress={()=>dispatch(removeItem(item))} />
                </View>
            ))}
        </View>
    );
};
export default Cart;