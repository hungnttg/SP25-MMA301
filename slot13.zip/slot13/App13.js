import React from "react";
import { Text,View } from "react-native";
import store from "./Store";
import ProductList from "./ProductList";
import Cart from "./Cart";
import { Provider } from "react-redux";
const products = [
    {id:1,name:'San pham 1'},
    {id:2,name:'San pham 2'},
    {id:3,name:'San pham 3'},
    {id:4,name:'San pham 4'},
];
const App13 = () =>{
    return(
        <Provider store={store}>
            <View>
                <ProductList products={products}/>
                <Cart/>
            </View>
        </Provider>
    );
};
export default App13;