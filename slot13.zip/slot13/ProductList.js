import React from "react";
import { View,Button,Text } from "react-native";
import { useDispatch } from "react-redux";
import { addItem,removeItem } from "./actions";
const ProductList = ({products}) =>{
    const dispatch = useDispatch();
    return(
        <View>
            {products.map(product =>(
                <View key={product.id}>
                    <Text>{product.name}</Text>
                    <Button title="Add to cart"
                    onPress={()=>dispatch(addItem(product))} />
                </View>
            ))}
        </View>
    );
};
export default ProductList;