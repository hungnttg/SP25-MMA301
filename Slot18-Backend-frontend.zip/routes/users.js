//npm i express
const express = require('express');
const router =  express.Router();
const User = require('../model/User');
//lay tat ca cac user
router.get('/',async (req,res)=>{
    try {
        res.json(await User.find());
    } catch (error) {
        res.status(500).json({message: error.message});
    }
});
//login
router.post('/login',async (req,res)=>{
    try {
        const user = await User.findOne({username: req.body.username});
        if(!user || user.password !== req.body.password){
            return res.status(401).json({message: 'Username, pass khong hop le'});
        }
        res.json({token: user.username, role: user.role});
    } catch (error) {
        res.status(500).json({message: 'Server error'});
    }
});
module.exports = router;