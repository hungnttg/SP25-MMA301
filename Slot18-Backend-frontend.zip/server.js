//npm i body-parser
//npm i cors
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser= require('body-parser');

const userRoutes = require('./routes/users');
const app = express();
const PORT= process.env.PORT || 5001;
//ket noi den mongodb
mongoose.connect('mongodb://localhost:27017/AoCuoi',{

}).then(()=>console.log('da ket noi'))
.catch(err=>console.log(err));
//
app.use(cors());
app.use(bodyParser.json());
//
app.use('/api/users',userRoutes);
//
app.listen(PORT,()=>{
    console.log('server dang chay o cong 5001');
});